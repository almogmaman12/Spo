from __future__ import annotations

import atexit
import json
from typing import Any, Callable, Dict, Type

import requests
from curl_cffi.requests import Response as TLSResponse
from curl_cffi.requests import Session
from curl_cffi.requests.exceptions import RequestException

from spotapi.exceptions import ParentException, RequestError
from spotapi.http.data import Response

ClientIdentifiers = str

__all__ = [
    "StdClient",
    "ClientIdentifiers",
    "TLSClient",
    "ParentException",
    "RequestError",
    "Response",
]


class StdClient:
    """
    Standard HTTP Client implementation wrapped around the requests library.
    """

    __slots__ = (
        "_client",
        "auto_retries",
        "authenticate",
    )

    def __init__(
        self,
        auto_retries: int = 0,
        auth_rule: Callable[[Dict[Any, Any]], Dict[Any, Any]] | None = None,
    ) -> None:
        self._client = requests.Session()
        self.auto_retries = auto_retries + 1
        self.authenticate = auth_rule
        atexit.register(self._client.close)

    def __call__(self, method: str, url: str, **kwargs) -> requests.Response | None:
        return self.build_request(method, url, **kwargs)

    def build_request(
        self, method: str, url: str | bytes, **kwargs
    ) -> requests.Response | None:
        if isinstance(url, (bytes, memoryview)):
            url = (
                url.tobytes().decode("utf-8")
                if isinstance(url, memoryview)
                else url.decode("utf-8")
            )

        err = "Unknown"
        for _ in range(self.auto_retries):
            try:
                response = self._client.request(method.upper(), url, **kwargs)
            except Exception as e:
                err = str(e)
                continue
            else:
                return response

        raise RequestError("Failed to complete request.", error=err)

    def parse_response(self, response: requests.Response) -> Response:
        body: str | Dict[Any, Any] | None = response.text
        headers = {key.lower(): value for key, value in response.headers.items()}

        if "application/json" in headers.get("content-type", ""):
            try:
                body = response.json()
            except ValueError:
                pass

        return Response(status_code=response.status_code, response=body, raw=response)

    def request(
        self, method: str, url: str | bytes, *, authenticate: bool = False, **kwargs
    ) -> Response:
        if authenticate and self.authenticate:
            kwargs = self.authenticate(kwargs)

        response = self.build_request(method, url, **kwargs)

        if response is not None:
            return self.parse_response(response)
        else:
            raise RequestError("Request kept failing after retries.")

    def post(
        self, url: str | bytes, *, authenticate: bool = False, **kwargs
    ) -> Response:
        return self.request("POST", url, authenticate=authenticate, **kwargs)

    def get(
        self, url: str | bytes, *, authenticate: bool = False, **kwargs
    ) -> Response:
        return self.request("GET", url, authenticate=authenticate, **kwargs)

    def put(
        self, url: str | bytes, *, authenticate: bool = False, **kwargs
    ) -> Response:
        return self.request("PUT", url, authenticate=authenticate, **kwargs)


class TLSClient(Session):
    """
    TLS-HTTP Client implementation wrapped around the curl_cffi library.

    This is fully undetected by Spotify.com.
    """

    def __init__(
        self,
        profile: ClientIdentifiers,
        proxy: str,
        *,
        auto_retries: int = 0,
        auth_rule: Callable[[Dict[Any, Any]], Dict[Any, Any]] | None = None,
    ) -> None:
        super().__init__(impersonate=profile)

        if proxy:
            self.proxies = {"http": f"http://{proxy}", "https": f"http://{proxy}"}

        self.auto_retries = auto_retries + 1
        self.authenticate = auth_rule
        self.on_auth_failure: Callable[[Response], bool] | None = None
        self.fail_exception: Type[ParentException] | None = None
        atexit.register(self.close)

    def __call__(self, method: str, url: str, **kwargs) -> TLSResponse | None:
        return self.build_request(method, url, **kwargs)

    def build_request(
        self, method: str, url: str | bytes, **kwargs
    ) -> TLSResponse | None:
        if isinstance(url, (bytes, memoryview)):
            url = (
                url.tobytes().decode("utf-8")
                if isinstance(url, memoryview)
                else url.decode("utf-8")
            )

        err = "Unknown"
        for _ in range(self.auto_retries):
            try:
                response = self.request(method.upper(), url, **kwargs)
            except RequestException as e:
                err = str(e)
                continue
            else:
                return response

        raise RequestError("Failed to complete request.", error=err)

    def parse_response(
        self, response: TLSResponse, method: str, danger: bool
    ) -> Response:
        body: str | Dict[Any, Any] | None = response.text
        headers = {key.lower(): value for key, value in response.headers.items()}

        # Spotify doesn't set content-type for some reason?
        json_encoded = "application/json" in headers.get("content-type", "")
        is_Dict = True

        try:
            json.loads(body)  # type: ignore
        except json.JSONDecodeError:
            is_Dict = False

        if json_encoded or is_Dict:
            json_formatted = response.json()
            body = json_formatted if isinstance(json_formatted, Dict) else body

        if not body:
            body = None

        resp = Response(
            status_code=int(response.status_code), response=body, raw=response
        )

        if danger and self.fail_exception and resp.fail:
            raise self.fail_exception(
                f"Could not {method} {str(response.url).split('?')[0]}. Status Code: {resp.status_code}",
                "Request Failed.",
            )

        return resp

    def _send(
        self,
        method: str,
        url: str | bytes,
        *,
        authenticate: bool,
        danger: bool,
        **kwargs,
    ) -> Response:
        if authenticate and self.authenticate is not None:
            kwargs = self.authenticate(kwargs)

        response = self.build_request(method, url, allow_redirects=True, **kwargs)
        if response is None:
            raise RequestError("Request kept failing after retries.")

        parsed = self.parse_response(response, method, False)

        if (
            authenticate
            and self.on_auth_failure is not None
            and self.authenticate is not None
            and parsed.fail
            and self.on_auth_failure(parsed)
        ):
            kwargs = self.authenticate(kwargs)
            response = self.build_request(method, url, allow_redirects=True, **kwargs)
            if response is None:
                raise RequestError("Request kept failing after retries.")
            parsed = self.parse_response(response, method, False)

        if danger and self.fail_exception and parsed.fail:
            raise self.fail_exception(
                f"Could not {method} {str(response.url).split('?')[0]}. Status Code: {parsed.status_code}",
                "Request Failed.",
            )

        return parsed

    def get(
        self, url: str | bytes, *, authenticate: bool = False, **kwargs
    ) -> Response:
        """Routes a GET Request"""
        return self._send("GET", url, authenticate=authenticate, danger=True, **kwargs)

    def post(
        self,
        url: str | bytes,
        *,
        authenticate: bool = False,
        danger: bool = False,
        **kwargs,
    ) -> Response:
        """Routes a POST Request"""
        return self._send(
            "POST", url, authenticate=authenticate, danger=danger, **kwargs
        )

    def put(
        self,
        url: str | bytes,
        *,
        authenticate: bool = False,
        danger: bool = False,
        **kwargs,
    ) -> Response:
        """Routes a PUT Request"""
        return self._send(
            "PUT", url, authenticate=authenticate, danger=danger, **kwargs
        )
